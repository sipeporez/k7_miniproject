-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: busan_subway_test
-- ------------------------------------------------------
-- Server version	8.0.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `station_list`
--

DROP TABLE IF EXISTS `station_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `station_list` (
  `station_no` int NOT NULL,
  `station_name` varchar(32) NOT NULL,
  `subway_line` char(3) NOT NULL,
  PRIMARY KEY (`station_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `station_list`
--

LOCK TABLES `station_list` WRITE;
/*!40000 ALTER TABLE `station_list` DISABLE KEYS */;
INSERT INTO `station_list` VALUES (95,'다대포해수욕장','1'),(96,'다대포항','1'),(97,'낫개','1'),(98,'신장림','1'),(99,'장림','1'),(100,'동매','1'),(101,'신평','1'),(102,'하단','1'),(103,'당리','1'),(104,'사하','1'),(105,'괴정','1'),(106,'대티','1'),(107,'서대신','1'),(108,'동대신','1'),(109,'토성','1'),(110,'자갈치','1'),(111,'남포','1'),(112,'중앙','1'),(113,'부산역','1'),(114,'초량','1'),(115,'부산진','1'),(116,'좌천','1'),(117,'범일','1'),(118,'범내골','1'),(119,'서면','1'),(120,'부전','1'),(121,'양정','1'),(122,'시청','1'),(123,'연산','1'),(124,'교대','1'),(125,'동래','1'),(126,'명륜','1'),(127,'온천장','1'),(128,'부산대','1'),(129,'장전','1'),(130,'구서','1'),(131,'두실','1'),(132,'남산','1'),(133,'범어사','1'),(134,'노포','1'),(201,'장산','2'),(202,'중동','2'),(203,'해운대','2'),(204,'동백','2'),(205,'벡스코','2'),(206,'센텀시티','2'),(207,'민락','2'),(208,'수영','2'),(209,'광안','2'),(210,'금련산','2'),(211,'남천','2'),(212,'경성대부경대','2'),(213,'대연','2'),(214,'못골','2'),(215,'지게골','2'),(216,'문현','2'),(217,'국제금융센터부산은행','2'),(218,'전포','2'),(219,'서면','2'),(220,'부암','2'),(221,'가야','2'),(222,'동의대','2'),(223,'개금','2'),(224,'냉정','2'),(225,'주례','2'),(226,'감전','2'),(227,'사상','2'),(228,'덕포','2'),(229,'모덕','2'),(230,'모라','2'),(231,'구남','2'),(232,'구명','2'),(233,'덕천','2'),(234,'수정','2'),(235,'화명','2'),(236,'율리','2'),(237,'동원','2'),(238,'금곡','2'),(239,'호포','2'),(240,'증산','2'),(241,'부산대양산캠퍼스','2'),(242,'남양산','2'),(243,'양산','2'),(302,'망미','3'),(303,'배산','3'),(304,'물만골','3'),(305,'연산','3'),(306,'거제','3'),(307,'종합운동장','3'),(308,'사직','3'),(309,'미남','3'),(310,'만덕','3'),(311,'남산정','3'),(312,'숙등','3'),(313,'덕천','3'),(314,'구포','3'),(315,'강서구청','3'),(316,'체육공원','3'),(317,'대저','3'),(402,'동래','4'),(403,'수안','4'),(404,'낙민','4'),(405,'충렬사','4'),(406,'명장','4'),(407,'서동','4'),(408,'금사','4'),(409,'반여농산물시장','4'),(410,'석대','4'),(411,'영산대','4'),(412,'윗반송','4'),(413,'고촌','4'),(414,'안평','4');
/*!40000 ALTER TABLE `station_list` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-23  8:40:08
